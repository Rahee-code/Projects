package chats;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.project_patt.R;

import java.util.List;

public class AdminChatAdapter extends RecyclerView.Adapter<AdminChatAdapter.AdminChatViewHolder> {
    private List<Messagemodel> messages;

    public AdminChatAdapter(List<Messagemodel> messages) {
        this.messages = messages;
    }

    @NonNull
    @Override
    public AdminChatViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_message, parent, false);
        return new AdminChatViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdminChatViewHolder holder, int position) {
        Messagemodel message = messages.get(position);
        holder.senderTextView.setText(message.getSenderId());
        holder.messageTextView.setText(message.getMessage());
        holder.timestampTextView.setText(message.getTimestamp());
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }

    public static class AdminChatViewHolder extends RecyclerView.ViewHolder {
        TextView senderTextView;
        TextView messageTextView;
        TextView timestampTextView;

        public AdminChatViewHolder(@NonNull View itemView) {
            super(itemView);
            senderTextView = itemView.findViewById(R.id.sender_text_view);
            messageTextView = itemView.findViewById(R.id.message_text_view);
            timestampTextView = itemView.findViewById(R.id.timestamp_text_view);
        }
    }
}