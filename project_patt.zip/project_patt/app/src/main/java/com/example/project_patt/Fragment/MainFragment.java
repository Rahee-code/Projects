package com.example.project_patt.Fragment;

import android.app.Activity;

public class MainFragment extends Activity {
}
