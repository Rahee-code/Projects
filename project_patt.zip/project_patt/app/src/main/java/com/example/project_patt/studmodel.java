package com.example.project_patt;

public class studmodel {
    private String stud;
    private int img;

    public studmodel() {
    }

    public studmodel(String stud, int img) {
        this.stud = stud;
        this.img = img;
    }

    public String getStud() {
        return stud;
    }

    public void setJob(String job) {
        this.stud = stud;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }
}
