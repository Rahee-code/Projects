package com.example.project_patt.Fragment;

import static java.security.AccessController.getContext;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.project_patt.R;
import com.example.project_patt.databinding.FragmentUploadPostBinding;

import java.util.Objects;
import java.util.zip.Inflater;

public class UploadPostFragment extends AppCompatActivity {
    FragmentUploadPostBinding binding;
    Bundle bundle;

    public UploadPostFragment() {

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_upload_post);
    }

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        binding = FragmentUploadPostBinding.inflate(inflater, container, false);

        binding.next.setOnClickListener(view -> {

            if (TextUtils.isEmpty(Objects.requireNonNull(binding.title.getText()).toString()))
                Toast.makeText(this, "Please enter title", Toast.LENGTH_SHORT).show();
            else if (TextUtils.isEmpty(Objects.requireNonNull(binding.description.getText()).toString())) {
                Toast.makeText(this, "Please enter description", Toast.LENGTH_SHORT).show();

            }else if (TextUtils.isEmpty(Objects.requireNonNull(binding.brand.getText()).toString())) {
                Toast.makeText(this, "Please enter brand", Toast.LENGTH_SHORT).show();

            }else if (TextUtils.isEmpty(Objects.requireNonNull(binding.model.getText()).toString())) {
                Toast.makeText(this, "Please enter model", Toast.LENGTH_SHORT).show();

            }else if (TextUtils.isEmpty(Objects.requireNonNull(binding.color.getText()).toString())) {
                Toast.makeText(this, "Please enter color", Toast.LENGTH_SHORT).show();

            }else if (TextUtils.isEmpty(Objects.requireNonNull(binding.size.getText()).toString())) {
                Toast.makeText(this, "Please enter size", Toast.LENGTH_SHORT).show();

            }else if (TextUtils.isEmpty(Objects.requireNonNull(binding.AdditionalInformation.getText()).toString())) {
                Toast.makeText(this, "Please enter AdditionalInformation", Toast.LENGTH_SHORT).show();

            }else if (TextUtils.isEmpty(Objects.requireNonNull(binding.price.getText()).toString())) {
                Toast.makeText(this, "Please enter price", Toast.LENGTH_SHORT).show();

            }else {

                getBundle();

                Fragment fragment = new UploadImageFragment();
                fragment.setArguments(bundle);
                FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.comname, fragment)
                        .addToBackStack("name")
                        .setReorderingAllowed(true)
                        .commit();
            }



        });


        return binding.getRoot();
    }

    private FragmentActivity requireActivity() {
        return null;
    }

    public Bundle getBundle() {

        String title = Objects.requireNonNull(binding.title.getText()).toString();
        String description = Objects.requireNonNull(binding.description.getText()).toString();

        String brand = Objects.requireNonNull(binding.brand.getText()).toString();
        String model = Objects.requireNonNull(binding.model.getText()).toString();

        String color = Objects.requireNonNull(binding.color.getText()).toString();
        String size = Objects.requireNonNull(binding.size.getText()).toString();

        String AdditionalInformation = Objects.requireNonNull(binding.AdditionalInformation.getText()).toString();
        String price = Objects.requireNonNull(binding.price.getText()).toString();

        bundle = new Bundle();
        bundle.putString("title", title);
        bundle.putString("description", description);

        bundle.putString("brand", brand);
        bundle.putString("model", model);

        bundle.putString("color", color);
        bundle.putString("size", size);

        bundle.putString("AdditionalInformation", AdditionalInformation);
        bundle.putString("price", price);


        return bundle;


    }
}